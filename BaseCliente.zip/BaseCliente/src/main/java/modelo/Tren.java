
package modelo;

import java.util.NoSuchElementException;


public class Tren {
    
    private String nombre;
    private String identificador;
    private int capacidadCarga;
    private double kilometraje;
    private String categoria;
    private int vagon;
    
    public Tren(String nombre, String identificador, String categoria) {
        this.identificador = identificador;
        if (nombre.equals("Mercedes-Benz")) {
            this.nombre = nombre;
            this.capacidadCarga = 28;
        } else if (nombre.equals("Arnold")) {
            this.nombre = nombre;
            this.capacidadCarga = 32;
        } else {
            throw new NoSuchElementException("Tiene que establecer alguno");
        }
        this.kilometraje = 0;
        if (categoria.equals("Estandar")) {
            this.categoria = categoria; 
            this.vagon = 22;
            // el costo por kilometraje aumenta (1000); 
        } else if (categoria.equals("Ejecutiva")) {
            this.categoria = categoria;
            this.vagon = 18;
            // el costo por kilometraje aumenta (1200); 
        } else if(categoria.equals("Premium")){
            this.categoria = categoria;
            this.vagon = 4;
            // el costo por kilometraje aumenta (1800); 
        } else{
            throw new NoSuchElementException("Tiene que establecer alguno que exista");
        }
    }
    
    // Constructor, getters y setters
}

