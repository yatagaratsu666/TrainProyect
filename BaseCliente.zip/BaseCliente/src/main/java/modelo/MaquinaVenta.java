
package modelo;

import brenda.listsingly.LinkedList;

public class MaquinaVenta {
    public void venderBoleto(Boleto boleto) {
        // Método para vender boleto
    }

    public LinkedList<Ruta> consultarRutasDisponibles() {
        // Método para consultar rutas disponibles
        return null;
    }

    public Ruta recomendarRutaMasCorta() {
        // Método para recomendar la ruta más corta
        return null;
    }
}
