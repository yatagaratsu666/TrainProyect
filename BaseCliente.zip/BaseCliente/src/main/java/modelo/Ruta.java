
package modelo;


public class Ruta {
    private Tren trenAsignado;
    private Estacion estaciones;
    private String horarios;
    private double precio;
    private float valor; //valor sera en base al kilometraje
    
    public void getValor(Ruta ruta){
        //consulta toda la información disponible sobre las rutas
        //dependera sobre el kilometraje el cual dependera 
    }

    // Constructor, getters y setters
}
