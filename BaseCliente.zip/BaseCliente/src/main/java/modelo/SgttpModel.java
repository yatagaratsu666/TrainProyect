
package modelo;

public class SgttpModel {
    
    private String title = "picha";
    public String getTitle(){
        return title;
    }
}
