
package controlador;

import modelo.Tren;

public class ControladorTrenes {

    public void agregarTren(Tren tren) {
        // Agrega trenes
    }

    public void eliminarTren(Tren tren) {
        // Elimina trenes
    }

    // Hacen falta algunos métodos como el de gestionar empleados, estación, etc.
}
