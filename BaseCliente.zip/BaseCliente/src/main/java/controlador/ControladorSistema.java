
package controlador;

import modelo.Ruta;
import modelo.Sistema;
import modelo.Tren;

public class ControladorSistema {
    
     private Sistema sistema;

    public ControladorSistema (Sistema sistema) {
        this.sistema = sistema;
    }

    public void agregarTren(Tren tren) {
        // Agrega trenes
    }

    public void eliminarTren(Tren tren) {
        // Elimina trenes
    }

    public void agregarRuta(Ruta ruta) {
        // Agrega rutas
    }

    public void eliminarRuta(Ruta ruta) {
        // Elimina rutas
    }

    // Hacen falta algunos métodos como el de gestionar empleados, estación, etc.
}
