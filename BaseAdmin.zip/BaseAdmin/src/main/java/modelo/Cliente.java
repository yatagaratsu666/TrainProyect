
package modelo;

import brenda.array.Array;

public class Cliente extends AbstractPerson {
    
    private String identification;
    private String address;
    
    public Cliente() {
        super();
        this.identification = "";
        this.address = "";
    }

    public Cliente(String name, String lastName, Array<String> phoneNumbers, String identification, String address) {
        super(name, lastName, phoneNumbers);
        this.identification = identification;
        this.address = address;
    }

    public String getIdentification() {
        return identification;
    }

    public void setIdentification(String identification) {
        this.identification = identification;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
