
package modelo;


public class Estacion {
    
    private String nombre;
    private int kilometraje; //de A a K tendra un kilometraje diferente
    
    // Constructor, getters y setters
}
