
package modelo;

import java.util.NoSuchElementException;


public class Boleto {
    private int idRegistro;
    private String fechaCompra;
    private String fechaSalida;
    private String fechaLlegada;
    private String identificacionPasajero;
    private String nombresPasajero;
    private String categoria;
    private String valor; //valor dependera de la categoria y ruta escogida
    
    //asignar getters y setters, se pretende que se relacione con los atributos del boleto ingresados por la maquina
}
