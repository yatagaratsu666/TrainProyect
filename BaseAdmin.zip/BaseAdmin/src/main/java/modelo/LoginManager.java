
package modelo;

public class LoginManager {
    
    public boolean login(String username, String password){
        return false;
    }
    
}
