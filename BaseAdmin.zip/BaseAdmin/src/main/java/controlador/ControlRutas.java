
package controlador;

import modelo.Ruta;


public class ControlRutas {
    
    public void agregarRuta(Ruta ruta) {
        // Agrega rutas
    }

    public void eliminarRuta(Ruta ruta) {
        // Elimina rutas
    }
    
    public void publicarRuta(Ruta ruta){
        //publica una ruta en especifico
    }
    
    public void modificarRuta(Ruta ruta){
        //modifica la información de la ruta en base a un constructor
    }
    
    public void modificarRecorridoRuta(Ruta ruta){
        //modifica la información de la ruta en base a un constructor
        //solo se modificara si no se ha iniciado
    }
    
    public void consultarRuta(Ruta ruta){
        //consulta toda la información disponible sobre las rutas
    }
    
    // cada ruta tendrá un aumento de kilometraje, se pretende hacer con grafos
    
}
