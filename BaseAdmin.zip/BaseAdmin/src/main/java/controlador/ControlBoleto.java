
package controlador;

import modelo.Cliente;

public class ControlBoleto {
    
    public void consultarBoleto(Cliente pasajero) {
        // Método para consultar boleto de un cliente
    }
    
    public void validarBoleto(Cliente pasajero) {
        // Método para consultar boleto de un cliente
    }
    
}
