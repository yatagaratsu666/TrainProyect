
package controlador;

public class ControlEquipaje {
    
}
