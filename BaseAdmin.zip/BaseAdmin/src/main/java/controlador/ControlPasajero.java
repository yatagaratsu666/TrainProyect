
package controlador;

import brenda.listsingly.LinkedList;
import modelo.Cliente;

public class ControlPasajero {
    private Cliente pasajeros;

    public ControlPasajero() {
        // Inicializar la lista de pasajeros
    }

    public void agregarPasajero(Cliente pasajero) {
        // Método para agregar un pasajero a la lista
    }

    public void eliminarPasajero(Cliente pasajero) {
        // Método para eliminar un pasajero de la lista
    }

    public LinkedList<Cliente> consultarPasajeros() {
        // Método para consultar la lista de pasajeros
        return null;
    }

    public Cliente buscarPasajeroPorIdentificacion(String identification) {
        // Método para buscar un pasajero por su identificación
        return null;
    }

    public LinkedList<Cliente> buscarPasajerosPorNombre(String nombre) {
        // Método para buscar pasajeros por su nombre
        return null;
    }

    public LinkedList<Cliente> buscarPasajerosPorApellido(String apellido) {
        // Método para buscar pasajeros por su apellido
        return null;
    }

}
